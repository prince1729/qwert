package com.deloitte.test;

import java.util.List;

import com.deloitte.dao.DoctorDAO;
import com.deloitte.entities.Doctor;

public class DoctorTest {
	public static void main(String args[]) {

//		Doctor d1 = new Doctor("asd", "qwe", "qwee");
//		DoctorDAO dDao = new DoctorDAO();
//		int id = dDao.saveDoctor(d1);
//		System.out.println(id);
//		
//		Doctor d2 = new Doctor("asdq", "qwed", "qweeg");
//		DoctorDAO d1Dao = new DoctorDAO();
//		int id1 = d1Dao.saveDoctor(d2);
//		System.out.println(id1);
//		
//		DoctorDAO d2Dao = new DoctorDAO();
//		List<Doctor> list=d2Dao.fetchDoctors();
//		System.out.println(list);
//		
//		DoctorDAO p1Dao= new DoctorDAO();
//		Doctor p2= p1Dao.fetchDoctorById(1);
//		System.out.println(p2);
		DoctorDAO p1Dao = new DoctorDAO();
		Doctor p2 = p1Dao.getUserByUsername("12345");
		System.out.println(p2);

	}
}
