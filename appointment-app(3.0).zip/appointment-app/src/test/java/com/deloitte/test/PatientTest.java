package com.deloitte.test;

import com.deloitte.dao.PatientDAO;
import com.deloitte.entities.Patient;

public class PatientTest {

		public static void main(String args[] ){
			
			Patient p1= new Patient("asd", 123455 );
			PatientDAO pDao= new PatientDAO();
			int id=pDao.savePatient(p1);
			System.out.println(id);
			
			PatientDAO p1Dao= new PatientDAO();
			Patient p2= p1Dao.fetchPatientById(1);
			System.out.println(p2);
		}
}
