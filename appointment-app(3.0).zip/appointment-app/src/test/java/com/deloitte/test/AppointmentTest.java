package com.deloitte.test;



import java.util.List;

import com.deloitte.dao.AppointmentDAO;
import com.deloitte.dao.DoctorDAO;
import com.deloitte.entities.Appointment;
import com.deloitte.entities.Doctor;
import com.deloitte.entities.Patient;

public class AppointmentTest {
	public static void main(String args[]) {
/*
		Doctor d1 = new Doctor("asd", "qwe", "qwee");
		Patient p1 = new Patient("asd", 12345567);
		Appointment a1 = new Appointment("21/21/2323",d1,p1);
		AppointmentDAO aDao = new AppointmentDAO();
		int id = aDao.saveAppointment(a1);
		System.out.println(id);
		
		Patient p2 = new Patient("asdqqq", 12345567);
		Appointment a2 = new Appointment("21/21/2323",d1,p2);
		AppointmentDAO a2Dao = new AppointmentDAO();
		int id2 = a2Dao.saveAppointment(a2);
		System.out.println(id2);
		
		Doctor d2 = new Doctor("asdw", "qwew", "qweew");
		Patient p3 = new Patient("asdwww", 12345563);
		Appointment a3 = new Appointment("21/21/2323",d2,p3);
		AppointmentDAO a3Dao = new AppointmentDAO();
		int id3 = a3Dao.saveAppointment(a3);
		System.out.println(id3);
		*/
		AppointmentDAO a4Dao= new AppointmentDAO();
		List<Appointment> a4= a4Dao.fetchAppointments(10, "2021-10-25");
		System.out.println(a4);
	}
}
