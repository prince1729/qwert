package com.deloitte.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.deloitte.entities.Doctor;
import com.deloitte.utils.HibernateHelper;

/**
 * 
 * @author Group 8.
 * It performs CRUD operations for Doctor entity.
 *
 */
public class DoctorDAO {
	private Session s;

	/**
	 * Constructor
	 * Session generated.
	 */
	public DoctorDAO() {
		s = HibernateHelper.getInstance().openSession();
	}

	/**
	 * 
	 * @param emp -> This is an doctor object which will be saved in doctor table.
	 * @return -> It returns the ID of saved doctor details.
	 */
	public int saveDoctor(Doctor emp) {
		int id = 0;
		try {
			Transaction tx = s.beginTransaction();
			id = (int) s.save(emp);
			tx.commit();
			System.out.println("Data Submitted Successfully...");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}

		return id;
	}

	/**
	 * 
	 * @return -> Returns all the doctor details.
	 */
	public List<Doctor> fetchDoctors() {

		List<Doctor> docList = new ArrayList<Doctor>();
		try {
			Query<Doctor> q = s.createQuery("from Doctor", Doctor.class);
			docList = q.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}
		return docList;
	}

	/**
	 * 
	 * @param dId -> Doctor ID.
	 * @return -> Returns doctor details according to doctor ID.
	 */
	public Doctor fetchDoctorById(int dId) {

		Doctor d = new Doctor();
		try {
			String query = "from Doctor where doctorId =: id";
			d = (Doctor) s.createQuery(query).setParameter("id", dId).uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}
		return d;
	}

	/**
	 * 
	 * @param username -> Doctor Username.
	 * @param password -> Doctor Password.
	 * @return -> Returns details of doctor according to Username and Password.
	 */
	public Doctor getUserByUsernameAndPassword(String username, String password) {
		

		Doctor d = new Doctor();
		try {
			String query = "from Doctor where username =: user and password =: pass";
			d = (Doctor) s.createQuery(query).setParameter("user", username).setParameter("pass", password).uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}
		return d;
	}

	/**
	 * 
	 * @param userName -> Doctor Username.
	 * @return -> Returns doctor details by username.
	 */
	public Doctor getUserByUsername(String userName) {
		
		
		Doctor d = new Doctor();
		try {
			String query = "from Doctor where username =: user";
			d = (Doctor) s.createQuery(query).setParameter("user", userName).uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}
		return d;
	}
}
