package com.deloitte.dao;

import org.hibernate.Session;

import org.hibernate.Transaction;

import com.deloitte.entities.Patient;
import com.deloitte.utils.HibernateHelper;

/**
 * 
 * @author Group 8.
 *
 */
public class PatientDAO {
	private Session s;

	/**
	 * Constructor
	 * Creates session
	 */
	public PatientDAO() {
		s = HibernateHelper.getInstance().openSession();
	}

	/**
	 * 
	 * @param emp -> This is an patient object which will be saved in patient table.
	 * @return -> Returns the ID of the saved patient.
	 */
	public int savePatient(Patient emp) {
		int pId = 0;
		try {
			Transaction tx = s.beginTransaction();
			pId = (int) s.save(emp);
			tx.commit();
			System.out.println("Data Submitted Successfully...");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}

		return pId;
	}

	/**
	 * 
	 * @param pId -> Patient ID
	 * @return -> Returns patient details by ID.
	 */
	public Patient fetchPatientById(int pId) {

		Patient p = new Patient();
		try {
			String query = "from Patient where patientId =: id";
			p = (Patient) s.createQuery(query).setParameter("id", pId).uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}
		return p;
	}

	/**
	 * 
	 * @param name-> Patient Name.
	 * @param mobile -> Patient Mobile no.
	 * @return -> Returns Patients details by Name and Mobile.
	 */
	public Patient getPatientByNameAndMobile(String name, String mobile) {
		
		Patient p = new Patient();
		try {
			String query = "from Patient where name =: n and mobile =: m";
			p = (Patient) s.createQuery(query).setParameter("n", name).setParameter("m", Long.parseLong(mobile)).uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}
		return p;
	}
}
