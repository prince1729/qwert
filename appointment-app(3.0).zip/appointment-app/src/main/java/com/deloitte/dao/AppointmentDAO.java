package com.deloitte.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.deloitte.entities.Appointment;
import com.deloitte.utils.HibernateHelper;

/**
 * 
 * @author Group 8
 * It performs CRUD operations for the appointment entity.
 *
 */
public class AppointmentDAO {

	private Session s;

	/**
	 * Constructor
	 */
	public AppointmentDAO() {
		s = HibernateHelper.getInstance().openSession();
	}

	/**
	 * 
	 * @param emp -> This is an appointment object which will be saved in appointment table.
	 * @return -> It returns the ID of saved appointment.
	 */
	public int saveAppointment(Appointment emp) {
		int id = 0;
		try {
			Transaction tx = s.beginTransaction();
			id = (int) s.save(emp);
			tx.commit();
			System.out.println("Data Submitted Successfully...");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}

		return id;
	}

	/**
	 * 
	 * @param dId -> Doctor ID.
	 * @param date -> Appointment date.(USed to fetch Appointment according to the date.)
	 * @return -> Returns list of Appointments.
	 */
	public List<Appointment> fetchAppointments(int dId, String date) {

		List<Appointment> appList = new ArrayList<Appointment>();
		try {
			Query<Appointment> q = s.createQuery("from Appointment where doctor_doctorId =: id and date =: d", Appointment.class)
					.setParameter("id", dId).setParameter("d", date);

			appList = q.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			s.close();
		}
		return appList;
	}

}
