package com.deloitte.servlets;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deloitte.dao.AppointmentDAO;
import com.deloitte.dao.DoctorDAO;
import com.deloitte.entities.Appointment;
import com.deloitte.entities.Doctor;
import com.deloitte.entities.Patient;

/**
 * 
 * @author Group 8. This is a Book Appointment Servlet.
 *
 */
public class BookServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4424959255424343674L;

	/**
	 * Called by the server (via the service method)to allow a servlet to handle a
	 * POST request.The HTTP POST method allows the client to senddata of unlimited
	 * length to the Web server a single timeand is useful when posting information
	 * such ascredit card numbers.
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		HttpSession s = req.getSession();

		try {

			// Getting Parameters.
			String doctor = req.getParameter("docList");

			String date = req.getParameter("select-date");
			
			//SSV
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDateTime now = LocalDateTime.now();
			String today = dtf.format(now).toString().replaceAll("-", "");
			
			//Comparing dates.
			String rDate = date.replaceAll("-", "");
			
			if(today.compareTo(rDate) > 0) {
				s.setAttribute("warning", "Please select a valid date!");
				resp.sendRedirect("book-appointment.jsp");
				return;
			}
			// Getting Patient details from session.
			Patient p = (Patient) req.getSession().getAttribute("user-patient");

			// Fetching doctor details.
			DoctorDAO dDao = new DoctorDAO();
			Doctor d = dDao.fetchDoctorById(Integer.parseInt(doctor));

			// Saving Appointment.
			AppointmentDAO aDao = new AppointmentDAO();
			int id = 0;
			id = aDao.saveAppointment(new Appointment(date, d, p));
			if (id != 0) {
				s.setAttribute("success", "Appointment successfull!");

				resp.sendRedirect("book-appointment.jsp");
			} else {

				s.setAttribute("warning", "Try again!");
				resp.sendRedirect("book-appointment.jsp");
			}

		} catch (Exception e) {
			s.setAttribute("warning", "Technical Error!");
			e.printStackTrace();
		}
	}
}
