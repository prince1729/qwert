package com.deloitte.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deloitte.dao.DoctorDAO;
import com.deloitte.dao.PatientDAO;
import com.deloitte.entities.Doctor;
import com.deloitte.entities.Patient;

/**
 * 
 * @author Group 8. This is a Login Servlet.
 *
 */
public class LoginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7810362031772808478L;

	/**
	 * Called by the server (via the service method)to allow a servlet to handle a
	 * POST request.The HTTP POST method allows the client to senddata of unlimited
	 * length to the Web server a single timeand is useful when posting information
	 * such ascredit card numbers.
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {

		HttpSession s = req.getSession();
		PrintWriter out = resp.getWriter();

		// Retrieve parameter values from HttpRequest
		String user = req.getParameter("user");
		if (user.equals("doctor")) {
			String username = req.getParameter("dusername");
			String password = req.getParameter("dpassword");

			System.out.println("username>>" + username);
			System.out.println("password>>" + password);

			// SSV->server side validation
			if (username.isEmpty() || password.isEmpty()) {
				System.out.println("Invalid Credentials");
				return;
			}

			// Fetching doctor details.
			DoctorDAO docDao = new DoctorDAO();
			Doctor d = docDao.getUserByUsernameAndPassword(username, password);
			if (d == null) {
				s.setAttribute("warning", "Invalid Credentials!");
				try {
					resp.sendRedirect("login.jsp");
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			} else {
				try {
					resp.sendRedirect("view-appointment.jsp");
					s.setAttribute("user-doctor", d);
					// s.setAttribute("user-doctorId", d.getId());
				} catch (IOException e) {
					
					e.printStackTrace();
				}

			}

			out.close();
		} else if (user.equals("patient")) {

			// Patient parameters form client-side.
			String name = req.getParameter("pname");
			String mobile = req.getParameter("pmobile");

			System.out.println("name>>" + name);
			System.out.println("mobile>>" + mobile);

			// SSV->server side validation
			if (name.isEmpty() || mobile.isEmpty()) {
				System.out.println("Enter your Details...");
				return;
			}
			int patientId = 0;

			// Fetching Patient details.
			PatientDAO pDao = new PatientDAO();
			Patient p = pDao.getPatientByNameAndMobile(name, mobile);
			if (p == null) {
				// Create patient
				PatientDAO patientDao = new PatientDAO();
				patientId = patientDao.savePatient(new Patient(name, Long.parseLong(mobile)));
				if (patientId == 0) {

					s.setAttribute("warning", "Unable to process request.");

				} else {
					resp.sendRedirect("book-appointment.jsp");
					s.setAttribute("user-patient", new PatientDAO().fetchPatientById(patientId));

				}
			} else {
				try {
					resp.sendRedirect("book-appointment.jsp");
					s.setAttribute("user-patient", p);

				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}

			out.close();
		}
	}
}
