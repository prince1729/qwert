package com.deloitte.servlets;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deloitte.dao.DoctorDAO;
import com.deloitte.entities.Doctor;

/**
 * 
 * @author Group 8. This is a Doctor Registration Servlet.
 *
 */
public class RegistrationServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4424959255424343674L;

	/**
	 * Called by the server (via the service method)to allow a servlet to handle a
	 * POST request.The HTTP POST method allows the client to senddata of unlimited
	 * length to the Web server a single timeand is useful when posting information
	 * such ascredit card numbers.
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		HttpSession s = req.getSession();

		try {

			// Doctor parameters from client-side.
			String userName = req.getParameter("dusername");

			String password = req.getParameter("dpassword");

			String name = req.getParameter("dname");

			// Server side verification.
			if (userName.trim().isEmpty()) {
				s.setAttribute("warning", "Username Invalid");

				resp.sendRedirect("register.jsp");
				return;

			}

			// Checking if doctor already exists.
			Doctor alreadyUser = new DoctorDAO().getUserByUsername(userName);
			System.out.println(alreadyUser);
			if (alreadyUser == null) {
				Doctor user = new Doctor(name, userName, password);
				DoctorDAO dDao = new DoctorDAO();
				int id = 0;
				id = dDao.saveDoctor(user);
				if (id != 0) {
					s.setAttribute("success", "Doctor registered successfully");

					resp.sendRedirect("login.jsp");
				} else {

					s.setAttribute("warning", "Not registered!");
					resp.sendRedirect("register.jsp");
				}
			} else {

				s.setAttribute("warning", "Username already exists!");
				resp.sendRedirect("register.jsp");

			}

		} catch (IOException e) {
			s.setAttribute("warning", "Not registered!");
			try {
				resp.sendRedirect("register.jsp");
			} catch (IOException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

}
