package com.deloitte.utils;

import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;

/**
 * 
 * @author Group 8.
 * This is to create session factory object.
 *
 */
public class HibernateHelper {
	
	private static SessionFactory sf;
	public static SessionFactory getInstance() {
		if(sf==null) {
			sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		}
		return sf;
	}
}
