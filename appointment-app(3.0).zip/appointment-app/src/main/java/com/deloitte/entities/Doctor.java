package com.deloitte.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * 
 * @author Group 8.
 * This is a Doctor entity.
 *
 */
@Entity
@Table(name = "doctor_tb")
public class Doctor {


		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "doctorId")
		private int id;

		@Column(name = "name", length = 50)
		private String name;

		@Column(name = "username", length = 50)
		private String username;

		@Column(name = "password", length = 15)
		private String password;

		@OneToMany(cascade= {CascadeType.ALL}, mappedBy="doctor")
		List<Appointment> appointment=new ArrayList<Appointment>();
		
		public List<Appointment> getAppointment() {
			return appointment;
		}

		public void setAppointment(List<Appointment> appointment) {
			this.appointment = appointment;
		}

		//Constructors.
		public Doctor() {
			
		}

		public Doctor(String name, String username, String password) {
			super();
			this.name = name;
			this.username = username;
			this.password = password;
		}

		public Doctor(int id, String name, String username, String password) {
			super();
			this.id = id;
			this.name = name;
			this.username = username;
			this.password = password;
		}
		

		//Getter Setter
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		@Override
		public String toString() {
			return "Doctor [id=" + id + ", name=" + name + ", username=" + username + ", password=" + password
					+"]";
		}

	}
