package com.deloitte.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 * @author Group 8.
 * This is Appointment entity.
 *
 */
@Entity
@Table(name = "appointment_tb")
public class Appointment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "appointmentId")
	private int aId;

	@Column(name = "date")
	private String date;

	@ManyToOne(cascade = { CascadeType.ALL })
	private Doctor doctor;

	@ManyToOne(cascade = { CascadeType.ALL })
	private Patient patient;

	//Constructors
	
	public Appointment() {

	}

	public Appointment(String date, Doctor doctor, Patient patient) {
		super();
		this.date = date;
		this.doctor = doctor;
		this.patient = patient;
	}

	public Appointment(int aId, String date, Doctor doctor, Patient patient) {
		super();
		this.aId = aId;
		this.date = date;
		this.doctor = doctor;
		this.patient = patient;
	}
	
	//Getter setter

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public int getaId() {
		return aId;
	}

	public void setaId(int aId) {
		this.aId = aId;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	
	@Override
	public String toString() {
		return "Appointment [aId=" + aId + ", date=" + date + ", doctor=" + doctor + ", patient=" + patient + "]";
	}

}
