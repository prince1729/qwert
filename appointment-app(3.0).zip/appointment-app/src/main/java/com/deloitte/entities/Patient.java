package com.deloitte.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * 
 * @author Group 8.
 * This is a Patient entity.
 *
 */
@Entity
@Table(name = "patient_tb")
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "patientId")
	private int id;
	@Column(name = "name", length = 50)
	private String name;

	@Column(name = "mobile", length = 10)
	private long mobile;
	
	@OneToMany(cascade= {CascadeType.ALL}, mappedBy="patient")
	List<Appointment> appointment=new ArrayList<Appointment>();

	//Constructor.
	public Patient() {
		
	}

	public Patient(int id, String name, long mobile) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
	}

	public Patient(String name, long mobile) {
		super();
		this.name = name;
		this.mobile = mobile;
	}

	public List<Appointment> getAppointment() {
		return appointment;
	}

	public void setAppointment(List<Appointment> appointment) {
		this.appointment = appointment;
	}

	//Getter Setter
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Patient [id=" + id + ", name=" + name + ", mobile=" + mobile + "]";
	}

}
